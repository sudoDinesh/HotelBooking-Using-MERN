export default function IndexPage() {
  return <div>index page here</div>;
}
